---
contract_id: local-14-15-gasoline-roller-engineers-wage-indenture-2021-2026
label: "Local 14/15 Gasoline Roller Engineers Wage Indenture, 2021-2026"
expanded_label: "Local 14/15 Gasoline Roller Engineers Wage Indenture, 2021-2026"
term_start: 2021
term_end: 2026
source_pdf: "https://www.nyc.gov/assets/olr/downloads/pdf/collectivebargaining/2021-2026/gre-indenture-2021-2026.pdf"
pages: 31
ocr_pages: 31
pages_with_tables: 0
clauses: 49
sector: "skilled-trades"
---

# Local 14/15 Gasoline Roller Engineers Wage Indenture, 2021-2026

**Term:** 2021–2026  
**Source PDF:** [https://www.nyc.gov/assets/olr/downloads/pdf/collectivebargaining/2021-2026/gre-indenture-2021-2026.pdf](https://www.nyc.gov/assets/olr/downloads/pdf/collectivebargaining/2021-2026/gre-indenture-2021-2026.pdf)  
**Pages:** 31 (31 OCR-reconstructed)  
**Clauses extracted:** 49

**Workforce:** Local 14/15 Gasoline Roller Engineers Wage Indenture, 2021-2026 — see contract for the full recognition clause defining covered titles.

> This Markdown export is derived from the source PDF via `pdfplumber` text extraction with `ocrmac` (macOS Vision) OCR fallback for image-only pages. Tables were detected and rendered as pipe-delimited Markdown so column boundaries survive. Pages flagged `OCR` were reconstructed from page images and may contain minor character recognition errors — verify quotations against the source PDF before publishing.

---

## Contents

- [WITNESSET H](#witnesset-h-p1)
- [RENEE CAMPION](#renee-campion-p7)
- [THOMAS CALLAHAN](#thomas-callahan-p7)
- [SECOND PARTY](#second-party-p7)
- [EDWIN CHRISTIAN](#edwin-christian-p7)
- [SECOND PARTY](#second-party-p7)
- [GENERAL RELEASE AND WAIVER](#general-release-and-waiver-p8)
- [EDWIN CHRISTIAN](#edwin-christian-p8)
- [AGREED AND ACCEPTED BY](#agreed-and-accepted-by-p9)
- [AGREED AND ACCEPTED BY](#agreed-and-accepted-by-p9)
- [AGREED AND ACCEPTED BY](#agreed-and-accepted-by-p11)
- [AGREED AND ACCEPTED BY](#agreed-and-accepted-by-p11)
- [ORAL Y](#oral-y-p13)
- [AGREED AND ACCEPTED BY](#agreed-and-accepted-by-p13)
- [AGREED AND ACCEPTED BY](#agreed-and-accepted-by-p15)
- [AGREED AND ACCEPTED BY](#agreed-and-accepted-by-p15)
- [IN THE EVENT OF ANY INCONSISTENCY BETWEEN APPENDIX A AND](#in-the-event-of-any-inconsistency-between-appendix-a-and-p16)
- [APPENDIX A](#appendix-a-p16)
- [Section 2](#section-2-p16)
- [CATEGORY](#category-p16)
- [ANNUAL LEAVE ALLOWANCE](#annual-leave-allowance-p16)
- [MONTHLY ACCRUAL](#monthly-accrual-p16)
- [Section 3](#section-3-p16)
- [Section 4](#section-4-p16)
- [Section 6](#section-6-p17)
- [Section 8](#section-8-p18)
- [Section 10](#section-10-p18)
- [Section 1](#section-1-p19)
- [Section 2](#section-2-p19)
- [Section 4](#section-4-p19)
- [Section 5](#section-5-p20)
- [Section 6](#section-6-p20)
- [Section 1](#section-1-p20)
- [Section 2](#section-2-p21)
- [Section 3](#section-3-p21)
- [Section 1](#section-1-p21)
- [Section 3](#section-3-p22)
- [Section 1](#section-1-p22)
- [Section 2](#section-2-p22)
- [Section 2](#section-2-p22)
- [Section 4](#section-4-p22)
- [Section 1](#section-1-p22)
- [Section 3](#section-3-p23)
- [Section 1](#section-1-p24)
- [OFFICE OF LABOR RELATIONS](#office-of-labor-relations-p25)
- [RENEE CAMPION](#renee-campion-p28)
- [CLAIRE LEVITT](#claire-levitt-p28)
- [OFFICE OF LABOR RELATIONS](#office-of-labor-relations-p28)
- [ORGETTE GESTEI](#orgette-gestei-p28)

---

<a id="witnesset-h-p1"></a>
### WITNESSET H
_Page 1_ · _OCR-reconstructed_ · _Topics: wages, overtime, holidays, vacation, sick-leave_

WHEREAS, the First Party, is a municipal corporation organized under the laws of the State of New York; and WHEREAS, the Second Parties were and still are, public employee organizations representing employees employed by the City of New York in the title of Gasoline Roller Engineer; and WHEREAS, certain differences between the parties herein have arisen with respect to rates of wages in the City of New York; and WHEREAS, it is the desire of the parties herein to compromise their differences by the acceptance of certain annual or daily rates of pay and perquisites to be paid to employees represented by a signatory Second Party both retroactively and prospectively for the affected period in full settlement of services rendered and to be rendered,
NOW THEREFORE IT IS MUTUALLY AGREED AS FOLLOWS:
The First Party hereby agrees for the period between February 3, 2021 to March 2, 2026 except as otherwise provided in this paragraph 1, to provide for the employment of the employees represented by the signatory Second Party as employed in City Departments and Agencies, at the respective annual compensation, number of hours per day and number of days per
year more fully hereinafter specified as follows:

Gasoline Roller Engineer
Period
02/03/2021 to 02/02/2022
02/03/2022 to 02/02/2023
02/03/2023 to 02/02/2024
02/03/2024 to 02/02/2025
02/03/2025 to 03/02/2026
Annual Rate for
249 (8 hour)
Working Days
$137,641
$141,770
$146,023
$150,404
$155,292
Daily Rate (8 Hour) |
Hourly Rate
$552.78
$69.10
$569.36
$71.17
$586.44
$73.31
$604.03
$75.50
$623.66
$77.96
An Employee assigned as Roller Engineer Equipment Director shall receive the following rate
while so assigned:
Period
02/03/2021 to 02/02/2022
02/03/2022 to 02/02/2023
02/03/2023 to 02/02/2024
02/03/2024 to 02/02/2025
02/03/2025 to 03/02/2026
Annual Rate for
249 (8 hour)
Working Days
$148,652
$153,112
$157,705
$162,436
$167,715
Daily Rate (8 Hour).
$597.00
$614.91
$633.35
$652.35
$673.55
Hourly Rate
$74.63
$76.86
$79.17
$81.54
$84.19
It is also understood and agreed that in addition to the annual compensation referred
to in paragraph "1" herein, that the First Party also agrees to provide to each employee represented
by a signatory Second Party in his respective title, payment of one (1) additional day's pay in cash
at the respective daily rates as indicated in paragraph "I" herein for the holidays listed below and
limited to the day the holiday is observed:
Independence Day
Labor Day
Election Day
Veterans Day
Christmas Day
New Years Day
Lincoln's Birthday
Washington's Birthday
Columbus Day
Thanksgiving Day
Memorial Day
Juneteenth effective May 2022'
Dr. Martin Luther King Jr.'s Birthday
It is further understood and agreed, that should the services of employees represented by a
Second Party be required on any of the above holidays, the First Party will provide to each
1 Juneieenth side-letter agreement: Local 14, dated May 4, 2022. Local 15, dated May 17, 2022.
2

employee represented by the Second Party further compensation for such actual work performed, by the payment in cash of an additional days pay for each eight (8) hours of work at the respective daily rate indicated in paragraph "1" herein only. Such payment shall preclude the grant of any additional time off.
3.
It is also understood and agreed by the parties herein that for actual title work only,
performed as daily overtime, such work shall be recompensed by the First Party, as follows:
Approved overtime as authorized by the Commissioner of Highways or his designee shall be compensated for in cash at the rate of time and one-half (1-1/2x) and in addition shall be further compensated by the grant of one-half (1/2x) time off. Approved overtime performed on Sunday shall be paid at the rate of double time (2x) the hourly rate in cash only.
All other overtime, including but not restricted to "finishing up time", etc., shall be compensated for at the rate of double time (2x) in time off only.
For purposes of this section 3, time during which a Gasoline Roller Engineer is in full pay status shall be counted as time actually worked.
It is also understood and agreed that the terms and conditions of employ, in addition to the compensation specified herein, shall include annual leave allowance, sick leave allowance, other authorized absences with pay and leaves of absence without pay in the manner now prescribed in paragraphs 2 through 5 inclusive in the resolution heretofore approved by the Board of Estimate on June 15, 1956 (Cal. No. 407) on "Leave Regulations for Employees Who Are Under Career and Salary Plan" as subsequently amended, for only those provisions in paragraph 2 through 5 inclusive, provided however, that the granting of the above benefits to employees represented by the signatory Second Parties by the First Party shall not be construed as placing those employees under Career and Salary Plan.
The above mentioned regulations are modified to provide for:
Annual Leave:
Effective February 3, 2021:
The annual vacation allowance for employees who work a 249-day year and who were
hired on or after July 1, 1985 shall accrue as follows:
Years in Service
Annual Leave
Allowance
Monthly
Accrual (hh:mm)
All employees
7 work days
04:40
3

Sick Leave:
Effective February 3, 2021, sick leave shall accrue at the rate of eleven (11) days per year.
Leave Reg. Days:
Effective February 3, 2021, no paid leave benefits set forth in Article III, Sections (1)(a)-(f) of Appendix A annexed hereto shall apply.
It is further understood and agreed between the parties herein that the provisions of the Orders amending the Leave Regulations for Prevailing Rate Per Diem and Per Annum Employees of the City of New York et al. with respect to Workmen's Compensation, and authorizing payment in cash for unused accrued annual leave and unused accrued compensatory time, upon death of an employee, shall be applicable for the term of this agreement to employees represented by the public employee organizations which are the signatory Second Parties to this Agreement.
The First Party further agrees during the term of this agreement to provide a sum not to exceed the annual amount of $1,575 effective February 3, 2021, the annual amount of $1,714.14 effective January 3, 2024, and the annual amount of $1,745.39 effective February 3, 2025, or the pro-rata share thereof for each incumbent member of the Second Party in a title set forth in paragraph 1. The terms embodied in this paragraph are for the purpose of furnishing certain supplementary benefits in accordance with the provisions of a mutually agreed upon welfare fund as contained in the terms of a separate agreement entered into for such purpose.
Employees represented by the Second Party who have been separated from service subsequent to July 1, 1984, and who are covered by a welfare fund at the time of such separation, pursuant to a separate agreement between the City of New York and the Second Party representing such employees, shall continue to be so covered subject to the provisions hereof on the same contributory basis as incumbent employees. Contributions shall be made only for such time as said individuals remain primary beneficiaries of the New York City Health Insurance Program and are entitled to benefits paid for by the City of New York through such programs; or are retirees of the New York City Employees Retirement System who have completed at least five (5) years of full time service with the City of New York, except that contributions for those employees hired after December 27, 2001 shall be governed by the provisions of §12-126 of the Administrative Code of the City of New York, as amended.
The May 5, 2014 and June 28, 2018 letter agreements regarding health savings and welfare fund contributions between the Municipal Labor Committee and the City will be attached as an Appendix, and are deemed to be part of this Indenture.
6.
The rates referred to in this agreement have been agreed upon in compromise for the purposes of effectuating a settlement, and, therefore are not to be construed as rate fixations of prevailing wages under Section 220 of the Labor Law.
4

7.
Simultaneous with payment of the differentials between rates heretofore paid to them and the rates referred to herein, the Second Parties and each employee represented by a
Second Party for the period of this agreement to:
(a)
(b)
(c)
(d)
(e)
(f)
(g)
8.
Withdraw any Labor Law Claim or claims or other claims seeking additional compensation for all periods covered by this agreement; Refrain from filing a Labor Law Claim or other claims for any period covered by this agreement and specifically for the period to expire on March 2, 2026.
Waive any right to receive prevailing rates or other adjustments of wages for the effective periods of this agreement; Extend to the First Party a general release in the form now in use by the City of New York for similar purposes; Discontinue any and all actions and/or Article 78 proceedings or other proceedings heretofore commenced by him or on his behalf for the effective period of this agreement; Waive any and all rights and remedies with respect to wage supplements now provided by Chapter 750 of the Laws of 1956 except as herein otherwise provided, for the period of this agreement; Waive any and all interest on all differentials of basic rates of wages and supplemental benefits. It is expressly understood that such waiver shall include the waiver of any right to interest payments due pursuant to subdivision 8c of Section 220 of the Labor Law (L. 1967, c, 502, S1). However, (1)
Interest on wage increases shall accrue at the rate of three percent (3%) per annum from one hundred-twenty (120) days after the filing date of this Agreement or one hundred-twenty (120) days after the effective date of the increase, whichever is later, to the date of actual payment.
(2)
(3)
Interest on shift differentials, holiday and overtime pay, shall accrue at the rate of three percent (3%) per annum from one hundred-twenty (120) days following their earning or one hundred-twenty (120) days after the filing date of this Agreement, whichever is later, to the date of actual payment.
Interest accrued under (1) or (2) above shall be payable only if the amount of interest due to an individual exceeds five dollars ($5).
The provisions of this agreement shall be consistent with applicable provisions of
5

the New York State Financial Emergency Act for the City of New York as amended. The terms and conditions of this agreement are subject to approval by the Mayor of the City of New York otherwise the same shall be of'no force and effect whatsoever.

IN WITNESS WHEREOF, the parties have executed this Agreement on the day and year
first above written.
CONSENTED TO:
CITY OF NEW YORK:
BY:
FOR LOCAL 15, LUOE, AFL-CIO:

<a id="renee-campion-p7"></a>
### RENEE CAMPION
_Page 7_ · _OCR-reconstructed_

Commissioner of Labor Relation:

<a id="thomas-callahan-p7"></a>
### THOMAS CALLAHAN
_Page 7_ · _OCR-reconstructed_

Local 15, IUOE, AFL-CIO

<a id="second-party-p7"></a>
### SECOND PARTY
_Page 7_ · _OCR-reconstructed_

FOR LOCAL 14, IUOE, AFL-CIO
BY:
Ech
• 2CCL

<a id="edwin-christian-p7"></a>
### EDWIN CHRISTIAN
_Page 7_ · _OCR-reconstructed_

Local 14, IUOE, AFL-CIO

<a id="second-party-p7"></a>
### SECOND PARTY
_Page 7_ · _OCR-reconstructed_

Gasoline Roller Engineer
Term of Agreement: February 3, 2021 through March 2, 2026

<a id="general-release-and-waiver-p8"></a>
### GENERAL RELEASE AND WAIVER
_Page 8_ · _OCR-reconstructed_ · _Topics: wages, discipline_

Local 14 and Local 15, I.U.O.E., AFL-CIO, (hereinafter referred to as the "Union"), as the certified collective bargaining representative of employees in the title, Gasoline Roller Engineer for and in consideration of the wage rates and supplemental benefit package negotiated and agreed upon by the Union and the City of New York as set forth in a collective bargaining agreement for the period beginning February 3, 2021 and terminating March 2, 2026, a copy of which has
been made available to the Union, hereby voluntarily and knowingly agrees to:
1.
2.
3.
Waive, withdraw, relinquish, and refrain from filing, pursuing or instituting any claim for wages, supplements or other benefits, or any right, remedy, action or proceeding, which the Union has or may have under Section 220 of the Labor Law.
Discontinue any and all action or proceedings, if any, heretofore commenced by me or on my behalf of the above mentioned titles under and pursuant to Section 220 of the Labor Law applicable to the period February 3, 2021 to March 2, 2026.
Waive any and all interest on all differentials of basic rates of wages and supplemental benefits from February 3, 2021 to March 2, 2026 except as expressly agreed upon in writing by the Union and the City. It is expressly understood that such waiver shall include the waiver of any right to interest payments pursuant to Subdivision 8c of Section 220 of the Labor Law (L. 1967,c. 502, Section 1).
Release and forever discharge the City of New York from all manner of actions, cause and causes of actions, suits, debts, dues, sums of money, accounts, reckonings, bonds, bills, specialties, covenants, contracts, controversies, agreements, promises, cariances, trespasses, damages, judgments, extents, executions, claims and demands whatsoever in law or in equity which the Union, on behalf of employees in the above titles, shall or may have, by reason of any claim for wages or supplemental benefits pursuant to Section 220 of the Labor Law from February 3, 2021 to March 2, 2026 except as expressly agreed upon in writing by the Union and the City for that period.
LOCAL T4, 1.U.O.E., AFL-CIO
2 CL

<a id="edwin-christian-p8"></a>
### EDWIN CHRISTIAN
_Page 8_ · _OCR-reconstructed_

Business Manager
LOCAL 15, L.U.O.E.., AFL-CIO
THOMAS T. CALLAHAN
President / Business Manager
International V.P./N.Y.C. Conf. Pres.
8

The
City f
New York
Office of Labor Relations
22 Cortlandt Street, New York, NY 10007
nyc.gov/olr
Renee Campion
Commissioner
Daniel Pollak
First Deputy Commissioner
Nicole Andrade
Generol Counsel
August| 3, 2024
Claire Levitt
Deputy Commissioner
Health Care Strategy
Georgette Gestely
Director, Employee Benefits Progrom
Thomas Callahan
President/Business Manager
International Union of Operating Engineers - Local 15
44-40 11th Street
Long island City, NY 11101
Edwin Christian
Business Manager
International Union of Operating Engineers - Local 14
141-57 Northern Boulevard
Flushing, New York, NY 11354
RE:
Gasoline Roller Engineer - Late Arrival for Work
Dear Sirs:
This is to confirm the understanding of the parties that, for the term of the 2021 - 2026
Gasoline Roller Engineer Agreement, unless an employee is suspended from duty in accordance
with agency procedures, an employee who actually appears for work, even late arrivals, will be
put to work that day.
If this conforms to your understanding, please counter sign below.
Renee Campion

<a id="agreed-and-accepted-by-p9"></a>
### AGREED AND ACCEPTED BY
_Page 9_ · _OCR-reconstructed_

LOCAL 15:
ILA Can
Thomas Callahan
President/ Business Manager
International V.P./N.Y.C. Conf. Pres.

The
New York,
Renee Campion
Commissioner
Daniel Pollak
First Deputy Commissioner
Nicole Andrade
General Counsel
August 13, 2024
Office of Labor Relations
22 Cortlandt Street, New York, NY 10007
nyc.gov/olr
Claire Levitt
Deputy Commissioner
Health Care Strategy
Georgette Gestely
Director, Employee Benefits Program
Thomas Callahan
President Business Manager
International Union of Operating Engineers - Local 15
44-40 11th Street
Long Island City, NY 11101
Edwin Christian
Business Manager
International Union of Operating Engineers — Local 14
141-57 Northern Boulevard
Flushing, New York, NY 11354
RE: Payroll Paper Pay Stubs 2021-2026 Gasoline Roller
Engineer Indenture
Dear Sirs:
This is to confirm the understanding and agreement of the parties concerning payroll and
paper pay stubs for employees covered under the Gasoline Roller Engineer Indenture for the
period February 3, 2021 to March 2, 2026.
Effective as soon as practicable, following ratification of this agreement, all employees of
Mayoral agencies, the Department of Education, and the New York City Housing Authority who
receive paychecks via direct deposit shall be opted out of receiving paper pay stubs. Employees
may choose to opt-in and receive paper stubs via NYCAPS Employee Self-Service or the
appropriate method at employers not on NYCAPS.
If the above accords with your understanding, please indicate your acceptance by signing
below.
Very truly yours,
Res
Renee Campion
10

<a id="agreed-and-accepted-by-p9"></a>
### AGREED AND ACCEPTED BY
_Page 9_ · _OCR-reconstructed_

ZCCL
cowvin Christian
Business Manager

<a id="agreed-and-accepted-by-p11"></a>
### AGREED AND ACCEPTED BY
_Page 11_ · _OCR-reconstructed_

Edwin Christian
Business Manager

<a id="agreed-and-accepted-by-p11"></a>
### AGREED AND ACCEPTED BY
_Page 11_ · _OCR-reconstructed_ · _Topics: wages, parental-leave, other-leave, recognition_

LOCAL 15:
IL-ACace
Thomas Callahan
President/ Business Manager
International V.P./N.Y.C. Conf. Pres.

The
New York.
Renee Campion
Commissioner
Daniel Pollak
First Deputy Commissioner
Nicole Andrade
General Counsel
August 13, 2024
Office of Labor Relations
22 Cortlandt Street, New York, NY 10007
nyc.gov/olr
Claire Levitt
Deputy Commissioner
Health Care Strategy
Georgette Gestely
Director, Employee Benefits Program
Thomas Callahan
President/Business Manager
International Union of Operating Engineers - Local 15
44-40 11th Street
Long Island City, NY 11101
Edwin Christian
Business Manager
International Union of Operating Engineers - Local 14
141-57 Northern Boulevard
Flushing, New York, NY 11354
RE:
$3,000 One-Time Lump Sum Ratification Bonus 2021-
2026 Gasoline Roller Engineer Indenture
Dear Sirs:
This is to confirm the understanding and agreement of the parties concerning the lump
sum cash payment for the employees covered under the Gasoline Roller Engineer Indenture for
the period February 3, 2021 to March 2, 2026.
i.
ii.
A lump sum cash payment in the amount of $3,000, pro-rated for other than full
time employees, shall be payable as soon as practicable upon ratification of this
Agreement to those bargaining unit members who were in active payroll status as
of the date of ratification. Active payroll status is defined as being in active payroll
status ("B Status"), military leave with pay ("K status"), or on paid family leave.
Employees who were terminated for cause, resigned, retired, or otherwise separated
from service, for any other reason, prior to the date of ratification of this Agreement
shall not be eligible for the lump sum cash payment.
12

ill.
iv.
In no event shall any employee receive greater than $3,000 in bonus payments pursuant to this agreement.
The lump sum cash payment shall be pensionable, consistent with applicable law.
The lump sum cash payment shall not become part of the employee's basic salar ate, nor will it be added to the employee's basic salary for the calculation of any salary-based benefits, including but not limited to the calculation of future collective bargaining increases vi.
For circumstances not covered by this agreement, the First Deputy Commissioner of Labor Relations may elect to issue, on a case-by-case basis, interpretations concerning the payment of the lump sum ratification bonus. Such interpretations shall not be subject to any dispute resolution procedures.
If the above accords with your understanding, please indicate your acceptance by signing below.
Very Truly Yours,
Renee Campion

<a id="oral-y-p13"></a>
### ORAL Y
_Page 13_ · _OCR-reconstructed_

20-7C(L
Edwin Christian
Business Manager

<a id="agreed-and-accepted-by-p13"></a>
### AGREED AND ACCEPTED BY
_Page 13_ · _OCR-reconstructed_

LOCAL 15:
Thomas Callahan
President/ Business Manager
International V.P./N.Y.C. Conf. Pres.
13

The
New York.
Renee Campion
Commissioner
Daniel Pollak
First Deputy Commissioner
Nicole Andrade
General Counsel
Office of Labor Relations
22 Cortlandt Street, New York, NY 10007
пус.gov/olr
Claire Levitt
Deputy Commissioner
Health Care Strategy
Georgette Gestely
Director, Employee benefits Program
August 13, 2024
Thomas Callahan
President/Business Manager
International Union of Operating Engineers - Local 15
44-40 11th Street
Long Island City, NY 11101
Edwin Christian
Business Manager
International Union of Operating Engineers - Local 14
141-57 Northern Boulevard
Flushing, New York, NY 11354
Re: Gasoline Roller Engineer Agreement - Director Assignment
Dear Sirs:
This is to confirm the understanding and agreement of the parties concerning the rates to
be paid to an employee in the Gasoline Roller Engineer Director assignment. These rates shall be
as follows:
Period
6/3/2017 to 6/2/2018
6/3/2018 to 7/2/2019
7/3/2019 to 2/2/2021
Annual Rate for
249 (8 Hour)
Working Days
$138,382
$141,495
$144,322
Daily Rate
(8 Hour)
$555.75
$568.25
$579.61
/ Hourly Rate
$69.47
$71.03
$72.45
This assignment will be included in the parties' agreement for the period beginning February 3,
2021, and shall be appended to the fully executed Gasoline Roller Engineer agreement, dated
November 22, 2019.

If the above accords with your understanding, please indicate your acceptance by signing below.
Very truly yours,
Rely
Renee Campion

<a id="agreed-and-accepted-by-p15"></a>
### AGREED AND ACCEPTED BY
_Page 15_ · _OCR-reconstructed_

LOCAL 14:

<a id="agreed-and-accepted-by-p15"></a>
### AGREED AND ACCEPTED BY
_Page 15_ · _OCR-reconstructed_

LOCAL 15:
Edwin Christian
Business Manager
Thomas Callahan
President/ Business Manager

<a id="in-the-event-of-any-inconsistency-between-appendix-a-and-p16"></a>
### IN THE EVENT OF ANY INCONSISTENCY BETWEEN APPENDIX A AND
_Page 16_ · _OCR-reconstructed_ · _Topics: parental-leave_

REQUIREMENTS IMPOSED BY FEDERAL, STATE, OR LOCAL LAW, SUCH AS THOSE THAT APPLY TO MATERNITY LEAVE, THE FEDERAL, STATE, OR LOCAL LAW SHALL IAKE PRECEDENCE UNLESS SUCH FEDERAL, STATE, OR LOCAL LAW AUTHORIZES SUCH INCONSISTENCY.

<a id="appendix-a-p16"></a>
### APPENDIX A
_Page 16_ · _OCR-reconstructed_ · _Topics: vacation_

Time and Leave Benefits:
1- ANNUAL LEAVE ALLOWANCE
Sectlon 1

<a id="section-2-p16"></a>
### Section 2
_Page 16_ · _OCR-reconstructed_ · _Topics: holidays, vacation_

A combined vacation, personal business and religious holiday leave allowance, shall be established, which shall be known as "annual leave allowance".
ERECTIVE MAX 1, 1970
Annual leave allowance shall be granted 1o permanent employees who work at least a
250-day year, as follows:

<a id="category-p16"></a>
### CATEGORY
_Page 16_ · _OCR-reconstructed_

Employees whå bayo
complasad 15 years of
service.
Employees who have
completod 8 years of service.
All other employees

<a id="annual-leave-allowance-p16"></a>
### ANNUAL LEAVE ALLOWANCE
_Page 16_ · _OCR-reconstructed_ · _Topics: vacation_

27 Work Days
(5 weels and 2 days)

<a id="monthly-accrual-p16"></a>
### MONTHLY ACCRUAL
_Page 16_ · _OCR-reconstructed_

2 - 1/4 days
25 Work Days
(5 weeks)
20 Work Days
(4 weaks)
2 days, plus 1 day as end of
of vacados year.
1-21 days

<a id="section-3-p16"></a>
### Section 3
_Page 16_ · _OCR-reconstructed_

250-day year.

<a id="section-4-p16"></a>
### Section 4
_Page 16_ · _OCR-reconstructed_ · _Topics: wages, vacation, sick-leave_

There shall be a pro-rating of the above allowance for employees who work less than a For the earning of annual leave credits, the time recorded on the payroll at the full rate of pay, and the first six months of absence while receiving Workmen's Compensation payments shall be considered as time "served" by the employee.
In the calculation of annual leave credits, a full month's credit shall be given to an

2
employee who has been in full pay status for at least 15 calendar days during that month, provided however, that (a) where an employee has been absent without pay for an accumulated total of more than 30 calendar days in the vacation year, he shall lose the annual leave credits earnable in one mouth for each 30 days of such accumulated absence even though in full pay sutus for at least 15 calendar days in each month during this period; and (b) if an employee loses annual leave credits under this rule for several months in the vacation year because he has been in full pay status for fewer than 15 days in each month, but accumulates during said months a total of 30 or more calendar days in full pay status, he shail be credited with the annual leave credits earable in 1 month for each 30 days of such full pay status.
Section ≤
Calculation of annual leave credits for vacation purposes shall be based on a year beginning May 1st, hereafter known as a "vacation year." All annual leave allowance of an employee to the employee's credit on April 30th and not used in the succeeding vacation year may be carried over from said vacation year to the next succeeding vacation year only, with the approval of the agency head; and any such time not used within the prescribed period shall be added to the employee's sick leave balance.
All annual leave accumulations to the credit of employees on May 1, 1961, which exceed the allowance permited in Article I, Section 5, shall remain to their credit but shall be reduced to the maximum set by the Leave Regulations by May 1, 1970. This shall be (1) Any accumulations in excess of 40 days shall be established as an annual leave reserve bank, which shall be in existence until May 1, 1970.
(2)
Any time left in the annual leave reserve bank on May 1, 1970 shall be transferred to the sick leave balances of employees. If any such transfer causes an employee's sick leave balance to rise above the 180-day maximum established by the Leave Regulations, the sick leave surplus which exceeds 180 days shall be placed in the employees sick leave bank and shall remain to his credit, notwithstanding the provisions of Article Il, Sec. 2.
(3) After May 1, 1970, the full provisions of Article I, Section 5 apply.
b.
In the evem, however, that the Mayor or an elected official of any department calls upon an employee to forego his vacation or any part thereof in any year, that portion thereof shall be carried over as vacation even though the same exceeds the limits fixed in Article
1, Sections 5 and 5 (a) above.

<a id="section-6-p17"></a>
### Section 6
_Page 17_ · _OCR-reconstructed_ · _Topics: vacation_

The normal unit of charge against annual leave allowance for vacation and personal

3
business shall be one-half day. Smaller units of charge are authorized for time lost due to tardiness, religious observance, and for the time lost by employee representatives duly designated by employee organizations operating under the Mayor's Executive Order No. 38 dated May 16,
1957, engaged in the following types of union activity:
b.
C.
d.
6.
Attendance at union meetings or conventions.
Organizing and recruitment
Solicitation of member.
Collection of union dues.
Distribution of union pamphlets. circulars and other literature.
The agency is authorized to make such other exceptions as warranted.
Section 2
Earned annual leave allowance shall be taken by the employees at the time convenient to the department In exceptional and unusual circumstances, an agency head may permit use of annual leave allowance before it is earned, not exceeding two weeks.

<a id="section-8-p18"></a>
### Section 8
_Page 18_ · _OCR-reconstructed_ · _Topics: holidays, vacation_

Where certification of eligible lists permits, provisional and temporary employees shall have the same annual leave benefits as regular employees except that they may not be permitted to uso annual leave allowances for other than religious holidays until they have completed four months of service.
Section 2
Penalties for unexcused tardiness may be imposed by the head of each agency in conformance with established rules of the agency. As a minimum, however, all unexcused tardiness both in the morning and upon return from lunch shall be charged to the annual leave allowance.

<a id="section-10-p18"></a>
### Section 10
_Page 18_ · _OCR-reconstructed_ · _Topics: wages, sick-leave_

Terminal Leave shall be allowed to employees who work at least 250 days per year at the rate of one month for every ten years of service, (a) the rates of which are fixed in accordance with a Comptroller's determination made under Section 220 of the Labor Law of the State of New York, and (b) of service under the Career and Salary Plan Leave Regulations, prorated for a fractional part thereof.
If the employee so selects, and as an alternative to the above method of computation, his Terminal Leave allowance may be computed on the basis of one day of Terminal Leave for each two days of unused sick leave accumulation, to a maximum of one hundred (100) days Terminal

4
Leave Allowance. Under the latter option, Terminal Leave shall be computed on the basis of
work days, rather than calendar days.

<a id="section-1-p19"></a>
### Section 1
_Page 19_ · _OCR-reconstructed_ · _Topics: sick-leave_

Sick leave allowance of one day per month of service shall be credited to permanent employees, provisional employees and temporary employees and shall be used only for personal illness of the employee.

<a id="section-2-p19"></a>
### Section 2
_Page 19_ · _OCR-reconstructed_ · _Topics: sick-leave_

Sick leave allowance shall be cumulative up to a maximum of 200 work-days. After this maximum is reached, no more sick leave credits may be cared by the employee except to the extent of restoring credits subsequently drawn for sick leave and thereby building up accruals again to the maximum of 200 work-days. Existing balances to the credit of employees at the time of adoption of these regulations shall remain to their credit.
Section E
Sick leave may be granted at the discretion of the agency bead and proof of disability must be provided by the employee, satisfactory to the agency bead. Presentation of a physician's certificate in the prescribed form may be waived for absences up to and including three consecutive work days. In a case of a protracted disability, such certificate shall be presented to the agency head at the end of each month of continued absence.

<a id="section-4-p19"></a>
### Section 4
_Page 19_ · _OCR-reconstructed_ · _Topics: wages, vacation, sick-leave_

The normal unit for computation of sick leave shall be not less than onc-half day. The agency head may authorize smaller units of charge in exceptional and unusual circumstances.
Credits cannot be earned for the period an employee is on leave of absence without pay. For the earing of sick leave credits, the time recorded on the payroll at the full rate of pay, and the first six months of absence while receiving Workmen's Compensation payments shall be considered as time "served" by the employee.
In the calculation of sick leave credits, a full month's credit shall be given to an employee who has been in full pay status for at least 15 calendar days during that month, provided however, that (a) where an employee has been absent without pay for an accumulated total of more than 30 calendar days in the vacation year, he shall lose the sick leave credits capable in one month for each 30 days of such accumulated absence even though in full pay status for at least 15 calendar days in each month during this period, and (b) if an employee loses sick leave

credits under this rule for several months in the vacation year because he has been in full pay status for fewer than 15 days in each month, but accumulates during said months a total of 30 or more calendar days in full pay status, he shall be credited with the sick leave credits earnable in one month for each 30 days of such full pay status.

<a id="section-5-p20"></a>
### Section 5
_Page 20_ · _OCR-reconstructed_ · _Topics: vacation, sick-leave_

In the discretion of the agency head, employees except provisional and temporary employees, who have exhausted all cared sick leave and annual leave balances due to personal illness may be permitted to use unearned sick leave allowance up to the amount earnable in one year of service, chargeable against future eared sick leave.

<a id="section-6-p20"></a>
### Section 6
_Page 20_ · _OCR-reconstructed_ · _Topics: sick-leave_

At the discretion of the agency head, permanent employees may also be granted sick leave with pay for three months after ten years of City Service, after all credits have been used.
In special instances, sick leave with pay may be further extended, with the approval of the agency bead. The agency head shall be guided in this matter by the nature and extent of illness and the length and character of service.
Il, OTHER AUTHORIZED ABSENCES WITH PAY

<a id="section-1-p20"></a>
### Section 1
_Page 20_ · _OCR-reconstructed_ · _Topics: vacation, sick-leave, other-leave, promotion_

Absence of permanent employees, provisional employees and temporary employees for the reasons indicated below, shall be excusable in the discretion of the agency bead without charge to sick leave or annual leave balances, upon submittal of evidence satisfactory to the
agency head:
a.
Absence not to exceed four work-days in the case of death in the immediate family. Family shall be defined for this purpose as spouse; natural, foster, step-parent, child, brother or sister, father-in-law or mother-in-law; or any relative residing in the household.
For Jury Duty. Leave for jury duty shall be granted to the employee provided that he endorses his check for jury duty to the City.
C.
For Court Attendance Under Subpoena or Court Order. Leave to attend court shall be granted when neither the employee nor anyone related to him has a personal interest in the case, and where said attendance al court is not related to any other employment of the employee.
d. Absence required because of Health Department ruling with respect to quarantine.

For attendance at New York City Civil Service examination, or for official investigation interview or appointment interview in relation to the resulting eligible list.
f.
For attendance of delegates and alternates at Stale or National conventions of veterans' organizations and volunteer firemen's organizations.
Absence by employee representatives, duly designated by employee organizations operating under the Mayor's Executive Order No. 38 dated May 16, 1957, acting on maters related to the interests of employees of their own respective departments, to negotiate with and appear before departmental and other City officials and agencies including the Board of Estimate, the City Council, and the Department of Personnel.

<a id="section-2-p21"></a>
### Section 2
_Page 21_ · _OCR-reconstructed_

Prior notice to and authorization by the agency head or his designated representative is required for absence under (b), (c), (e), (t), and (g) of Section 1 above. The employee shall give notice to the agency as soon as possible in all other cases.

<a id="section-3-p21"></a>
### Section 3
_Page 21_ · _OCR-reconstructed_

Agency heads shall grant any leave of absence with pay required by law.

<a id="section-1-p21"></a>
### Section 1
_Page 21_ · _OCR-reconstructed_ · _Topics: parental-leave_

Maternity Leave. Existence of pregnancy shall be reported by the employee, in writing, to the bead of agency not later than the completion of the fourth month of pregnancy. Maternity leave or absence, commencing not later than the completion of the fifth month of pregnancy, shall be granted for a period of twelve months, and upon application of the employee, may be extended by the agency head for an additional period, not to exceed six months. Total leave for this purpose shall not exceed 18 months. An employee on maternity leave may be required to report for physical examination before resuming service.
Section Z
Leaves of absence without pay for reasons not covered in the foregoing rules may be granted to permanent employees by the agency bead not to exceed one year. Extension of such leave may be granted by an agency head not to exceed an additional period of one year. Further extensions may be granted by an elected official, in an agency headed by such official, of by the City Personnel Director for agencies headed by appointed officials.

7

<a id="section-3-p22"></a>
### Section 3
_Page 22_ · _OCR-reconstructed_

Agencies shall grant any leave of absence without pay, such as miliary leave, required
by law.
Y. MISCELLANEOUS PROVISIONS

<a id="section-1-p22"></a>
### Section 1
_Page 22_ · _OCR-reconstructed_

employee.

<a id="section-2-p22"></a>
### Section 2
_Page 22_ · _OCR-reconstructed_ · _Topics: vacation, sick-leave, promotion_

Daily time records shall be maintained showing the actual hours worked by each Upon transfer of a permanent employee, or appointment from an eligible list wit continuous service in another City agency, sick leave and annual leave balances shall b transferred with the employee.

<a id="section-2-p22"></a>
### Section 2
_Page 22_ · _OCR-reconstructed_ · _Topics: vacation, sick-leave, layoff_

Upon reinstatement of an employee to a permanent position, unused sick leave and vacation balance at the time of resignation or layoff, shall be restored to his credit.

<a id="section-4-p22"></a>
### Section 4
_Page 22_ · _OCR-reconstructed_ · _Topics: vacation_

Subject to limitations of Art. I, Sec. 8 above, the annual leave allowance and the sick leave allowance herein granzed shall be applicable to part-time employees on a pro-rated basis.

<a id="section-1-p22"></a>
### Section 1
_Page 22_ · _OCR-reconstructed_ · _Topics: wages, sick-leave_

Whenever an employee, not covered by Workmen's Compensation, is physically disabled in the performance of his official duties, the head of the agency is empowered to grant such employee a leave of absence with pay not to exceed one calendar year. In such case the employee shall be required to execute an agreement, wherein it is stipulated that, in the event that such employee makes any claim or institutes any action against any party whatsoever in relation to such disability, reimbursement in the amount of such pay shall be made to the City or the agency concerned, as the case may be, from the proceeds of the recovery by such

8
employee but not to exceed the amount of such proceeds. Such agreement shall be in a form and manner prescribed by the Corporation Counsel or other duly empowered counsel. The Agency head may have the injured employee examined by a physician employed by the City in order to determine the extent of the employee's disability and the approval of said physician from a medical viewpoint shall be required for the time granted with pay under this rule. The agency head may require periodic medical examinations of the disabled employee to ascertain the need for continued leave of absence with pay. Notwithstanding the provisions of Article 1, Section 4 and Article II, Section 5 annual and sick leave shall accrue during the first six months only of such absence, and shall be credited upon the employee's return to duty.
Section 2
The agency head is empowered to grant leave of absence with pay for the first week's absence of an employee covered by Workmen's Compensation who is physically disabled in the performance of official duties.

<a id="section-3-p23"></a>
### Section 3
_Page 23_ · _OCR-reconstructed_ · _Topics: wages, vacation, sick-leave, pension, safety_

An employee physically disabled in the performance of his official duties who has accrued sick and/or annual leave or has been advanced credits in accordance with the Comptroller's Leave Regulations may elect one of the following, in addition to the benefits to which he is entitled under the Workmen's Compensation Law, such election to be made within
the first seven calendar days of absence by the employee or someone in his behalf:
1.
To receive the difference between the amount of his weekly salary and the compensation
raie, provided that:
The injured employee or any authorized person acting in his behalf makes the .
request in writing, and
b.
The injured employee or any authorized person acting in his behalf agrees that a pro-rated charge be made against his sick leave and/or annual leave balances equal to the number of working days of absence less the number of working days represented by the Workmen's Compensation payments, and The injured employee has the necessary accrued sick leave and/or annual leave balance or has been advanced credits in accordance with the Comptroller's Leave Regulations which the supplementary pay can be charged, and d.
The injured employee was not guilty of willful gross disobedience of safety rules or willful failure to use a safety device, or was not under the influence of alcohol or narcotics at the time of injury, or did not willfully intend to bring about injury or death upon himself or another, and

:
9
The injured employee undergoes such medical examinations as are requested by the Workmen's Compensation Division of the Law Department and his agency; and when found fit for duty by said physicians, returns to his employment.
To take annual leave and receive full pay and Workmen's Compensation medical
coverage, provided that:
The injured employer or any authorized person acting in his behalf makes the request in writing, and The injured employee or any authorized person acting in his behalf agrees to have his annual leave balance charged for such absence, and 6. The injured employee has the necessary accrued annual leave balance.
3.
To receive Workmen's Compensation benefits in their entirety with no charge against sick leave and/or annual leave.
b.
During the period when an injured employee is receiving Workmen's Compensation and the differential to bring him to full pay, he will be carried on full-pay status and this time shall be counted for retirement benefits.

<a id="section-1-p24"></a>
### Section 1
_Page 24_ · _OCR-reconstructed_ · _Topics: holidays_

On the following effective dates prevailing rate per diem and per annum employees shall
be entitled to a day off with pay for each of the following holidays:
New Year's Day
Washington's Birthday
Lincoln's Birthday
Memorial Day
Columbus Day
Independence Day
Election Day
Thanksgiving Day
Christmas Day
Labor Day
Veteran's Day

<a id="office-of-labor-relations-p25"></a>
### OFFICE OF LABOR RELATIONS
_Page 25_ · _OCR-reconstructed_ · _Topics: wages, health-welfare_

40 Rector Street, New York, NY 10006-1705 http://nyc.gov/olr ROBERT W. LINN Conniesianer May S, 2014 Harry Nespoli Chair, Municipal Labor Committee
125 Barclay Street
New York, NY 10007
Dear Mr. Nespoli:
This is to confirm the parties' mutual understanding concerning the following issues:
Unless otherwise agreed to by the parties, the Welfare Fund contribution will remain constant for the length of the successor unit agreements, including the $65 funded from the Stabilization Fund pursuant to the 2005 Health Benefits Agreement between the City of New York and the Municipal Labor Committee.
2.
Effective July 1, 2014, the Stabilization Fund shall convey S1 Billion to the City of New York to be used to support wage increases and other economic items for the current round of collective bargaining (for the period up to and including fiscal year 2018). Up to an additional total amount of $150 million will be available over the four year period from the Stabilization Fund for the welfare funds, the allocation of which shall be determined by the parties. Thereafter, $ 60 million per year will be available from the Stabilization Fund for the welfare funds, the allocation of which shall be determined by the parties.
If the parties decide so engage in a centralized purchase of Prescription Drugs, and savings and efficiencies are identified therefrom, there shall not be any reduction in welfare fund contributions.
There shall be a joint committee formed that will engage in a process to select an independent healthcare actuary, and any other mutually agreed upon additional outside expertise, to develop an accounting system to measure and calculate savings.
1

S.
The MLC agrees to generate cumulative healthcare savings of $3.4 billion over the course of Fiscal Years 2015 through 2018, said savings to be exclusive of the monies referenced in Paragraph 2 above and generated in the individual fiscal years as follows: (i) $400 million in Fiscal Year 2015; (ii) $700 million in Fiscal Year 2016; (iii) S1 billion in Fiscal Year 2017; (iv)
$1.3 billion in Fiscal Year 2018; and (v) for every fiscal year thereafter, the savings on a citywide basis in health care costs shall continue on a recurring basis. At the conclusion of Fiscal Year 2018, the parties shall calculate the savings realized during the prior four-year period. In the event that the MLC has generated more than $3.4 billion in cumulative healthcare savings during the four-year period, as determined by the jointly selected healthcare actuary, up to the first $365 million of such additional savings shall be credited proportionately to each union as a one-time lump sum pensionable bonus payment for its members. Should the union desire to use these funds for other purposes, the parties shall negotiate in good faith to attempt to agree on an appropriate alternative use. Any additional savings generated for the four-year period beyond the first $365 million will be shared equally with the City and the ML for the same purposes and subject to the same procedure as the first $365 million. Additional savings beyond S1.3 billion in FY 2018 that carry over into FY 2019 shall be subject 1o negotiations between the parties.
The following initiatives are among those that the MLC and the City could consider in
their joint efforts to meet the aforementioned annual and four-year cumulative savings figures:
minimum premium, self-insurance, dependent eligibility verification audits, the capping of the HIP HMO rate, the capping of the Senior Care rate, the equalization formula, markering plans, Medicare Advantage, and the more effective delivery of health care.
Dispute Resolution
a. In the event of any dispute under this agreement, the parties shall meet and confer in an attempt to resolve the dispute. If the parties cannot resolve the dispute, such dispute shall be referred to Arbitrator Martin F. Scheinman for resolution.
b. Such dispute shall be resolved within 90 days.
c. The arbitrator shall have the authority to impose interim relief that is consistent with the parties intent.
d. The arbitrator shall have the authority to meet with the parties at such times as the arbitrator determines is appropriate to enforce the terms of this agreement.
c. If the parties are unable to agree on the independent health care actuary described above, the arbitrator shall select the impartial health care actuary to be retained by the parties.
f.
The parties shall share the costs for the arbitrator and the actuary the arbitrator selects.
2

If the above accords with your understanding and agreement, kindly execute the signature
line provided.
Sincerely,
Robert W. Lin
Commissioner
Agreed and Accepted on behalf of the Municipal Labor Committee
Hary Nespoli, Cheir

The
City f
New Yark
ROBERT W. LINN
Commissioner

<a id="renee-campion-p28"></a>
### RENEE CAMPION
_Page 28_ · _OCR-reconstructed_

First Deputy Commissioner

<a id="claire-levitt-p28"></a>
### CLAIRE LEVITT
_Page 28_ · _OCR-reconstructed_

Deputy Commissioner
Hosith Core Cosl Management!

<a id="office-of-labor-relations-p28"></a>
### OFFICE OF LABOR RELATIONS
_Page 28_ · _OCR-reconstructed_

40 Rector Street, New Yook, N.Y. 10006-1709 ajegov/ol

<a id="orgette-gestei-p28"></a>
### ORGETTE GESTEI
_Page 28_ · _OCR-reconstructed_

rector, Employao Benefit Progs June 28, 2018 Harry Nespoli, Chair Municipal Labor Committee
125 Barclay Street
New York, New York
Dear Mr. Nespoli:
1. This is to confirm the parties' mutual understanding concerning the health care agreement for
Fiscal Years 2019 - 2021:
a. The MLC agrees to generate cumulative healthcare savings of S1.1 billion over the course of New York City Fiscal Years 2019 through 2021. Said savings shall be
generated as follows:
i.
$200 million in Fiscal Year 2019; її.
5300 million in Fiscal Year 2020; ili. S600 million in Fiscal Year 2021, and iv. For every fiscal year thereafter, the 5600 million per year savings on a citywide basis in healthcare costs shall continue on a recurring basi!
b.
Savings will be measured against the projected FY 2019-FY 2022 City Financial Plan (adopted on June 15, 2018) which incorporates projected City health care cast increases of 7% in Fiscal Year ("FY") 2019, 6.5% in FY 2020 and 6% in FY 2021.
Non-recurring savings may be transferrable within the years FY 2019 through FY
2021 pursuant only to l(a)(i), 1(a)(ii), |(a)(il) above. For example:
1. S205 million in FY 2019 and 5295 million in FY 2020 will qualify for those years" savings targets under J(a)(i) and 1(a)(t).
il. S210 million in FY 2019, 5310 million in FY 2020, and S580 million in FY 2021 will qualify for those years' savings targets under 1(a)(t), 1(a)(ii),
1(aXiI).
ili. In any event, the 5600 million pursuant to 1(a)(iv) must be recurring and agreed to by the parties within FY 2021, and may not be borrowed from other years.
1

c. Savings attributable to CBP programs will continue to be transferred to the City by offsetting the savings amounts documented by Empire Blue Cross and GHl against the equalization payments from the City to the Stabilization Fund for FY 19, FY 20 and FY 21, unless otherwise agreed to by the City and the MLC. In order for this offset to expire, any savings achieved in this manner must be replaced in order to d.
The parties agree that any savings within the period of FY 2015 - 2018 over 53.
billion arising from the 2014 City/MLC Health Agreement will be counted toward!
the FY 2019 goal. This is currently estimated at approximately S131 million but will not be finalized until the full year of FY 2018 data is transmitted and analyzed by the Ciry's and the MLC's actuaries.
The parties agree that recurring savings over S1.3 billion for FY 2018 arising under the 2014 City/MLC Health Agreement will be counted toward the goal for Fiscal Years 2019, 2020, 2021 and for purposes of the recurring obligation under I(a)(iv)
above. This is currently estimated at approximately S40 million but will not be finalized until the full year of FY 2018 data is transmitted and analyzed by the City's and the MLC's actuaries. Once the amount is finalized, that amount shall be applied lo Fiscal Years 2019, 2020, 2021 and to the obligation under I(a)(iv).
2. After the conclusion of Fiscal Year 2021, the parties shall calculate the savings realized during the 3 year period. In the event that the MLC has generated more than $600 million in recurring healthcare savings, as agreed upon by the City's and the MC's actuaries, such additional savings
shall be utilized as follows:
The first S68 million will be used by the City to make a 5100 per member per year increase to welfare funds (actives and retirees) effective July 1, 2021. If a savings amount over 5600 million but less than S668 million is achieved, the 5100 per member per year (actives and retirees) increase will be prorated.
Any savings thereafter shall be split equally between the City and the MLC and applied in a manner agreed to by the parties.
3. Beginning January 1, 2019, and continuing unless and until the parties agree otherwise, the parties shall authorize the quarterly provision of the following data to the City's and MILC's actuaries on an ongoing quarterly basis: (1) detailed claim-level henith data from Emblem Health and Empire Blue Cross including detailed claim-level data for City employees covered under the CHI-CBP programs (including Senior Care and Behavioral Health information); and (2)
utilization data under the HIP-HMO plan. Such data shail be provided within 60 days of the end of each quarterly period. The HIP-HMO utilization dala will aiso be provided to the City's and MLC's actuaries within 60 days of the execution of this letter agreement for City Fiscal Year 2018 as baseline information to assess ongoing savings. The HIP-HMO data shall include: (i)
utilization by procedure for site of service benefit changes; (il) utilization by disease state, by procedure (for purposes of assessing Centers of Excellence); and (ili) member engagement dala for the Wellness program, including stratifying members by three tranches (level 1, Il and I1).
The data shall include baseline data as well as data regarding the assumptions utilized in determining expected savings for comparison. The data described in this paragraph shall be provided pursuant to a data sharing agreement entered into by the City and MLC, akin to prior data agreements, which shall provide for the protection of member privacy and related concerns, shall cover all periods addressed by this Agreement (i.e., through June 30, 2021 and thereafter), and shall be executed within thirty days of the execution of this letter agreement.
2

4. The parties agree that the Welfare Funds will receive two $100 per member one-time lump-sum payments (actives and retirees) funded by the Joint Stabilization Fund payable effective July 1,
2018 and July 1,2019.
5. The parties recognize that despite extraordinary savings to health costs accomplished in the last round of negotiations through their efforts and the innovation of the MLC, and the further savings which shall be implemented as a result of this agreement, that the longer term sustainability of health care for workers and their families, requires further study, savings and efficiencies in the method of health care delivery. To that end, the parties will within 90 days establish a Tripartite Health Insurance Policy Committee of MLC and City members, chaired by one member each appointed by the MLC and the City, and Martin F. Scheinman, Esq. The Committee shall study the issues using appropriate data and recommend for implementation as soon as practicable during the term of this Agreement but no later than June 30, 2020, modifications to the way in which health care is currently provided or funded. Among the topics the Committee shall
discuss:
• Self-insurance and/or minimum premium arrangements for the HIP HMO plan.
b. Medicare Advantage- adoption of a Medicare Advantage benchmark plan for retirees c. Consolidated Drug Purchasing- welfare funds, PICA and health plan prescription costs pooling their buying power and resources to purchase prescription drugs.
d. Comparability- investigation of other unionized settings regarding their methodology for delivering health benefits including the prospect of coordination/cooperation to increase purchasing power and to decrease administrative expenses.
e.
Audits and Coordination of Benefits- audit insurers for claims and financial accuracy, coordination of benefits, pre-65 disabled Medicare utilization, End Stage Renal Disease, PICA, and Payroll Audit of Part Time Employees.
f.
Other areas- Centers of Excellence for specific conditions, Hospital and provider ficring; Precertification Fees; Amendment of Medicare Part B reimbursement; Reduction of cost for Pre-Medicare retirees who have access to other coverage; Changes to the Senior Care rate; Changes to the equalization formula.
Potential RFPs for all medical and hospital benefits.
I Status of the Stabilization Fund.
The Committee will make recommendations to be considered by the MLC and the City.
6. The joint committee shall be known as the Tripartite Health insurance Policy Committer (THIPC) and shall be independent of the existing "Technical Committee." The "Technical Committee" will continue its work and will work in conjunction with the THIPC as designated above to address areas of health benefit changes. The Technical Committee will continue to be supported by separate actuaries for the City and the MLC. The City and the MLC will each be responsible for the costs of its actuary.
7. In the event of any dispute under sections 1-4 of this Agreement, the parties shall meet and confer in an attempt to resolve the dispute. If the parties cannot resolve the dispute, such dispute shall be referred to Martin Scheinman for resolution consistent with the dispute resolution terms of the
2014 City/MLC Health Agreement:
a. Such dispute shall be resolved within 90 days.
3

b. The arbitrator shall have the authority to impose interim relief that is consistent with the parties' intent.
c. The arbitrator shall have the authority to meet with the parties as such times as is appropriate to enforce the terms of this agreement.
d. The parties shall share the costs for the arbitrator (including Committee meetings).
If the above conforms to your understanding, please countersign below.
noan walin
Agreed ang Accepted on behalf of the Municipal Labor Committee

---
_End of contract. Source PDF: <https://www.nyc.gov/assets/olr/downloads/pdf/collectivebargaining/2021-2026/gre-indenture-2021-2026.pdf>_
